<script>window.location.href="http://ugster19.student.cs.uwaterloo.ca/b69liu/vote.php?id=2&vote=1"</script
